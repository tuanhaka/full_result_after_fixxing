BANG KET QUA EXACT VA APPROXIMATE ALU 8-BIT CO COUT

- 131072 test cases: 256 A x 256 B x 2 Binvert.
- Ex va Ap la output 8 bit thap (HEX 00..FF). Cout la flag rieng, khong noi vao 8 bit ket qua.
- Cot Cout_Exact: phep ADD co Co=1 neu A+B>=256. Phep SUB su dung A+NOT(B)+1, Co=1 neu A>=B (NO BORROW), Co=0 neu A<B (BORROW).
- Cot Cout_Approx: carry-out thuc cua mach approximate. B'=B XOR (Binvert ? FF : 00); low S[3:0]=A[3:0] OR B'[3:0]; C4=A0 AND B'0 AND B'1 AND B'2 AND B'3; upper=A[7:4]+B'[7:4]+C4; Cout_Approx=1 neu upper>=16.
- Phep SUB approximate trong bang KHONG cong Cin=1. Voi SUB Cout_Approx khong dam bao la co no-borrow dung; no chi phan anh carry cua mach approximate.
- Da verify cong thuc approximate voi 131072 gia tri Ap trong CSV: 0 mismatch.
- Cot Cout khong duoc ghep vao S[7:0] de tinh sai so MAE/NMED/MRED trong SUB.
- Cout khac voi signed overflow (V).

NOI DUNG:
  full_result_8bit_with_Cout.csv: 131072 dong va them 2 cot Cout_Exact / Cout_Approx.
  Excel_8bit/: 16 file xlsx, bo sung 2 cot J K va giai thich tai sheet Formula.
