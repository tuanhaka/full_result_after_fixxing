#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Compare an 8-bit approximate ALU against exact arithmetic on RGB images.
Uses the actual Ap lookup values in full_result_8bit.csv (or its enclosing ZIP),
not a simplified approximate-adder equation.

Install:
    pip install numpy pillow matplotlib scikit-image

Examples:
    python test_approx_alu_images.py --lut "full_result_8bit.zip" --image input.png --operation add --constant 20
    python test_approx_alu_images.py --lut "full_result_8bit.zip" --image image_a.png --image2 image_b.png --operation add --scale-half
    python test_approx_alu_images.py --lut "full_result_8bit.zip" --image images_folder --operation sub --constant 20

All exact outputs obey modulo-256 arithmetic (8-bit output; carry discarded).
These results are software emulation of a truth table, not a timing/power simulation.
"""

import argparse
import csv
import io
import math
import zipfile
from pathlib import Path

import matplotlib
matplotlib.use("Agg")  # Ve anh ra file, khong can giao dien do hoa
import matplotlib.pyplot as plt
import numpy as np
from PIL import Image
from skimage.metrics import peak_signal_noise_ratio, structural_similarity

EXTENSIONS = {".png", ".jpg", ".jpeg", ".bmp", ".tiff", ".tif", ".webp"}


def read_lut(csv_or_zip: Path) -> np.ndarray:
    """Return LUT[binvert, A, B] with dtype uint8, shape (2, 256, 256)."""
    if csv_or_zip.suffix.lower() == ".zip":
        with zipfile.ZipFile(csv_or_zip, "r") as archive:
            names = [name for name in archive.namelist() if name.lower().endswith(".csv")]
            if not names:
                raise ValueError("ZIP khong chua file CSV.")
            selected = next((n for n in names if Path(n).name.lower() == "full_result_8bit.csv"), names[0])
            with archive.open(selected) as binary:
                text = io.TextIOWrapper(binary, encoding="utf-8-sig", newline="")
                return parse_csv(text)
    with csv_or_zip.open("r", encoding="utf-8-sig", newline="") as text:
        return parse_csv(text)


def parse_csv(text) -> np.ndarray:
    lut = np.zeros((2, 256, 256), dtype=np.uint8)
    seen = np.zeros_like(lut, dtype=bool)
    reader = csv.DictReader(text)
    required = {"A", "B", "Binvert", "Ex", "Ap"}
    if not reader.fieldnames or not required.issubset(reader.fieldnames):
        raise ValueError("CSV phai co cac cot A, B, Binvert, Ex, Ap")
    for row in reader:
        a = int(row["A"].strip(), 16)
        b = int(row["B"].strip(), 16)
        op = int(row["Binvert"].strip())
        exact_csv = int(row["Ex"].strip(), 16)
        approx = int(row["Ap"].strip(), 16)
        if not (0 <= a <= 255 and 0 <= b <= 255 and op in (0, 1) and 0 <= approx <= 255):
            raise ValueError(f"Du lieu 8-bit khong hop le: {row}")
        if seen[op, a, b]:
            raise ValueError(f"Trung lap to hop: Binvert={op}, A={a:02X}, B={b:02X}")
        expected = ((a + b) if op == 0 else (a - b)) & 0xFF
        if exact_csv != expected:
            raise ValueError(
                f"Cot Ex khong dung tai A={a:02X}, B={b:02X}, Binvert={op}: "
                f"Ex={exact_csv:02X}, expected={expected:02X}"
            )
        lut[op, a, b] = approx
        seen[op, a, b] = True
    if not np.all(seen):
        missing = np.argwhere(~seen)
        raise ValueError(f"CSV thieu {len(missing)} to hop. Vi du: {missing[0].tolist()}")
    return lut


def load_image(path: Path, target_size=None) -> np.ndarray:
    with Image.open(path) as img:
        rgb = img.convert("RGB")
        if target_size and rgb.size != target_size:
            rgb = rgb.resize(target_size, Image.Resampling.BILINEAR)
        return np.asarray(rgb, dtype=np.uint8)


def compute_metrics(exact: np.ndarray, approx: np.ndarray) -> dict:
    error = np.abs(exact.astype(np.int16) - approx.astype(np.int16)).astype(np.float64)
    mae = float(error.mean())
    mse = float(np.mean(error ** 2))
    psnr = float(peak_signal_noise_ratio(exact, approx, data_range=255))
    if min(exact.shape[:2]) < 7:
        raise ValueError("Anh can co kich thuoc toi thieu 7x7 pixel de tinh SSIM.")
    ssim = float(structural_similarity(exact, approx, data_range=255, channel_axis=-1))
    return {
        "MAE": round(mae, 6),
        "MSE": round(mse, 6),
        "NMED_percent": round(mae / 255 * 100, 6),
        "PSNR_dB": round(psnr, 6),
        "SSIM": round(ssim, 6),
        "Exact_pixel_percent": round(float(np.all(exact == approx, axis=2).mean() * 100), 6),
        "Exact_channel_percent": round(float(np.mean(exact == approx) * 100), 6),
        "Max_absolute_error": int(error.max()),
    }


def save_comparison(input_img, exact, approx, output_png, operation, metrics):
    error = np.abs(exact.astype(np.int16) - approx.astype(np.int16)).mean(axis=2)
    fig, axs = plt.subplots(1, 4, figsize=(17, 4.8), constrained_layout=True)
    axs[0].imshow(input_img)
    axs[0].set_title("Anh dau vao A")
    axs[1].imshow(exact)
    axs[1].set_title(f"Exact {operation.upper()} (8-bit)")
    axs[2].imshow(approx)
    axs[2].set_title(f"Approximate {operation.upper()} (8-bit)")
    im = axs[3].imshow(error, cmap="inferno", vmin=0, vmax=255)
    axs[3].set_title("Sai so tuyet doi trung binh RGB")
    for ax in axs:
        ax.axis("off")
    fig.colorbar(im, ax=axs[3], fraction=0.047, pad=0.04, label="Sai so [0, 255]")
    fig.suptitle(
        f"PSNR = {metrics['PSNR_dB']:.3f} dB  |  SSIM = {metrics['SSIM']:.5f}  |  "
        f"MAE = {metrics['MAE']:.3f}  |  NMED = {metrics['NMED_percent']:.3f}%",
        fontsize=12,
    )
    fig.savefig(output_png, dpi=150, bbox_inches="tight")
    plt.close(fig)


def save_rgb(array, path):
    Image.fromarray(array, mode="RGB").save(path)


def input_images(path: Path):
    if path.is_file():
        return [path]
    if path.is_dir():
        files = sorted(p for p in path.iterdir() if p.is_file() and p.suffix.lower() in EXTENSIONS)
        if not files:
            raise ValueError(f"Thu muc {path} khong co anh hop le.")
        return files
    raise FileNotFoundError(f"Khong tim thay anh/thu muc: {path}")


def main():
    parser = argparse.ArgumentParser(description="Kiem chung Approximate ALU 8-bit tren anh RGB")
    parser.add_argument("--lut", type=Path, required=True, help="full_result_8bit.csv hoac file ZIP")
    parser.add_argument("--image", type=Path, required=True, help="Anh thu nhat A, hoac thu muc anh")
    parser.add_argument("--image2", type=Path, default=None, help="Anh thu hai B, hoac thu muc anh cung ten")
    parser.add_argument("--operation", choices=["add", "sub"], default="add")
    parser.add_argument("--constant", type=int, default=20, help="B=0..255 neu khong dung --image2")
    parser.add_argument("--scale-half", action="store_true", help="Chia A va B cho 2 truoc khi ADD; tranh overflow trong cong hai anh")
    parser.add_argument("--output", type=Path, default=Path("image_results"))
    args = parser.parse_args()

    if not (0 <= args.constant <= 255):
        parser.error("--constant phai trong khoang 0..255")
    lut = read_lut(args.lut)
    args.output.mkdir(parents=True, exist_ok=True)
    rows = []
    for i, path in enumerate(input_images(args.image), start=1):
        a = load_image(path)
        if args.image2 is None:
            b = np.full_like(a, args.constant)
        else:
            source_b = (args.image2 / path.name) if args.image2.is_dir() else args.image2
            if not source_b.is_file():
                raise FileNotFoundError(f"Khong tim thay anh B: {source_b}")
            b = load_image(source_b, target_size=(a.shape[1], a.shape[0]))

        if args.scale_half:
            a = a // 2
            b = b // 2

        a_signed = a.astype(np.int16)
        b_signed = b.astype(np.int16)
        exact_int = a_signed + b_signed if args.operation == "add" else a_signed - b_signed
        exact = np.asarray(exact_int & 0xFF, dtype=np.uint8)
        op = 0 if args.operation == "add" else 1
        approximate = lut[op, a, b]
        metrics = compute_metrics(exact, approximate)
        label = f"{i:03d}_{path.stem}_{args.operation}"
        dest = args.output / label
        save_rgb(a, dest.with_name(label + "_input.png"))
        save_rgb(exact, dest.with_name(label + "_exact.png"))
        save_rgb(approximate, dest.with_name(label + "_approx.png"))
        save_comparison(a, exact, approximate, dest.with_name(label + "_comparison.png"), args.operation, metrics)
        row = {"image": path.name, "operation": args.operation, "B": str(args.image2 or args.constant), "half": args.scale_half, **metrics}
        rows.append(row)
        print(f"[{i}] {path.name}: PSNR={metrics['PSNR_dB']:.3f} dB | SSIM={metrics['SSIM']:.5f} | "
              f"MAE={metrics['MAE']:.3f} | NMED={metrics['NMED_percent']:.3f}%")

    output_csv = args.output / "metrics.csv"
    with output_csv.open("w", encoding="utf-8-sig", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        writer.writeheader()
        writer.writerows(rows)
    if len(rows) > 1:
        print(f"\nTrung binh tren {len(rows)} anh:")
        for key in ("PSNR_dB", "SSIM", "MAE", "NMED_percent", "Exact_pixel_percent"):
            print(f"  {key}: {np.mean([r[key] for r in rows]):.5f}")
    print(f"\nSave pictures and parameters in: {args.output.resolve()}")


if __name__ == "__main__":
    main()
